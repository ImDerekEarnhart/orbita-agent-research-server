"""Built-in Orbita domains."""
